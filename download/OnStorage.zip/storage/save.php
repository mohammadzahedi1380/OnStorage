﻿<?php
if ((!empty($_POST['value'])) || ($_POST['value'] == 0)) {
	$type = $_POST['type'];
	$userId = $_POST['userId'];
	$token = $_POST['token'];
	$column = $_POST['column'];
	$old_value = $_POST['oldValue'];
	$language = $_POST['lang'];
	$value = $_POST['value'];
	if ($type == 'select') {
		$value = ($value=="false" ? 0 : 1);
	}
	include('language/' . $language . '.php');
	require_once 'include/class.user.php';
	$user_home = new USER();
	try {
		$sql = "UPDATE {$token}_variables SET $column='$value' WHERE user_id=?";
		$stmt = $user_home->prepareQuery($sql);
		$stmt->bind_param('s', $userId);
		if ($stmt->execute()) {
			if ($type == 'select') {
				$value = ($value==0 ? "false" : "true");
			}
			echo $value;
		} else {
			echo $old_value;
		}
	} catch (Exception $e) {
		if (strpos($e->getMessage(), 'Duplicate') !== false) {
			echo '<script>alert("' . $lang['duplicate_value_error'] . '");</script>';
		} else {
			echo '<script>alert("' . $lang['database_error'] . '");</script>';
		}
		echo $old_value;
	}
}