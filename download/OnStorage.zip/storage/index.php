﻿<?php
	include_once('header.php');
	if(!$user_home->is_logged_in()) {
		$user_home->redirect('login.php');
	}
	$message = "";
	$json = file_get_contents("https://raw.githubusercontent.com/miladesign/OnStorage/master/version.txt");
	$obj = json_decode($json);
	$latest = $obj->version;
	$sdk_url = explode("@", $obj->url);
	$sdk_names = explode("@", $obj->$language);
	if (!empty($_GET['update'])) {
		$message = sprintf($lang['update_success'], $latest);
	}
?>
<?php if (!empty($message)) { ?>
	<div id="message">
		<div class="alert alert-success" id="alert">
			<?= $message; ?>
		</div>
	</div>
<?php } ?>
      <div class="row">
			<div class="col">
				<div class="widget">
					<div class="widget-header"> <i class="fas fa-tasks"></i>
						<h3> <?= $lang['shortcodes']; ?></h3>
					</div>
					<div class="widget-content">
						<a class="btn btn-info btn-block" style="width: 100%;" href="games.php#addgame"><i class="fas fa-plus-circle"></i> <?= $lang['add_game']; ?></a>
					</div>
				</div>
			</div>
			<div class="col">
				<div class="widget">
					<div class="widget-header"> <i class="fas fa-book"></i>
						<h3> <?= $lang['docs']; ?></h3>
					</div>
					<div class="widget-content">
						<?php
							foreach($sdk_url as $i =>$key) {
								$iName =$sdk_names[$i];
								$i >0;
								echo '<a class="btn btn-info" style="width: 100%;" href="'.$key.'">'.$iName.'</a><br>';
							}
						?>
					</div>
				</div>
			</div>
			<div class="col">
				<div class="widget">
					<div class="widget-header"> <i class="far fa-list-alt"></i>
						<h3> <?= $lang['onstorage']; ?> <?= $version; ?></h3>
					</div>
					<div class="widget-content">
						<?php
							if($version >= $latest) {
								echo '<a class="btn btn-success" style="width: 100%;" href="#">'.sprintf($lang['version_ok'], $version).'</a><br>';
							} else {
								echo '<a class="btn btn-danger" style="width: 100%;" href="http://parscore.ir">'.sprintf($lang['new_version'], $latest).'</a><br>';
							}
						?>
						<a class="btn btn-info" style="width: 100%;" href="http://parscore.ir"><?= $lang['support_site']; ?></a>
					</div>
				</div>
			</div>
	  </div>
<?php include_once('footer.php'); ?>