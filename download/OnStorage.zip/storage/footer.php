		</div>
		<footer class="footer">
			<div class="container">
				<p class="text-muted"><?= $lang['footer_text']; ?></p>
			</div>
		</footer>
	</body>
</html>
